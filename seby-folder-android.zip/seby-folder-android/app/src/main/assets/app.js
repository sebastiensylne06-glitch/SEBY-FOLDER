const menu=document.getElementById('menuToggle');const nav=document.getElementById('mainNav');if(menu&&nav)menu.addEventListener('click',()=>nav.classList.toggle('open'));
// Offline mode: member count cannot be fetched from the remote server.
const count=document.getElementById('memberCount');if(count)count.textContent='—';
