# SEBY FOLDER Android offline starter

This Android WebView app loads the included local HTML/CSS/JS assets, so the home screen opens without internet.

## Important offline limitation
The original Express routes (`/api/register`, `/api/login`, member count, admin APIs) require the remote Node.js server and SQLite database. They are not implemented as local offline account storage in this starter. The APK is an offline home-screen prototype; online account features need internet and server integration.

## Build
The GitHub Actions workflow installs Gradle and builds `android/app/build/outputs/apk/debug/app-debug.apk`. Open Actions and run **Build SEBY FOLDER APK**, then download the artifact.
